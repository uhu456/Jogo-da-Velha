package edu.harvard.cs50.jogodavelha

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.view.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun btClick(view: View){
        val btSelect = view as Button
        var cellID = 0

        when(btSelect.id){
            R.id.bu1 -> cellID = 1
            R.id.bu2 -> cellID = 2
            R.id.bu3 -> cellID = 3
            R.id.bu4 -> cellID = 4
            R.id.bu5 -> cellID = 5
            R.id.bu6 -> cellID = 6
            R.id.bu7 -> cellID = 7
            R.id.bu8 -> cellID = 8
            R.id.bu9 -> cellID = 9
        }

        //Toast.makeText(this, "ID: "+cellID, Toast.LENGTH_SHORT).show()
        playGame(cellID,btSelect)
        checkWiner()
    }

    //Array para guarda as jogadas
    var player1 = ArrayList<Int>()
    var player2 = ArrayList<Int>()
    //turno do jogador
    var activeplayer = 1

    fun playGame(cellID:Int, btSelect:Button){
            if (activeplayer==1){
                btSelect.text = "X"
                btSelect.setBackgroundColor(Color.GREEN)
                player1.add(cellID)
                activeplayer = 2
            }else{
                btSelect.text = "O"
                btSelect.setBackgroundColor(Color.MAGENTA)
                player2.add(cellID)
                activeplayer = 1
            }
        btSelect.isEnabled = false
    }

    fun checkWiner(){
        var winer = -1

        //Linha 1
        if (player1.contains(1) && player1.contains(2) && player1.contains(3)){
            winer = 1
        }
        if (player2.contains(1) && player2.contains(2) && player2.contains(3)){
            winer = 2
        }
        //Linha 2
        if (player1.contains(4) && player1.contains(5) && player1.contains(6)){
            winer = 1
        }
        if (player2.contains(4) && player2.contains(5) && player2.contains(6)){
            winer = 2
        }
        //Linha 3
        if (player1.contains(7) && player1.contains(8) && player1.contains(9)){
            winer = 1
        }
        if (player2.contains(7) && player2.contains(8) && player2.contains(9)){
            winer = 2
        }
        ///////////////////////Colunas//////////////////////////
        //Coluna 1
        if (player1.contains(1) && player1.contains(4) && player1.contains(7)){
            winer = 1
        }
        if (player2.contains(1) && player2.contains(4) && player2.contains(7)){
            winer = 2
        }
        //Coluna 2
        if (player1.contains(2) && player1.contains(5) && player1.contains(8)){
            winer = 1
        }
        if (player2.contains(2) && player2.contains(5) && player2.contains(8)){
            winer = 2
        }
        //Coluna 3
        if (player1.contains(3) && player1.contains(6) && player1.contains(9)){
            winer = 1
        }
        if (player2.contains(3) && player2.contains(6) && player2.contains(9)){
            winer = 2
        }
        ////////////////////Cruzamento////////////////////
        //Cruzamento 1
        if (player1.contains(1) && player1.contains(5) && player1.contains(9)){
            winer = 1
        }
        if (player2.contains(1) && player2.contains(5) && player2.contains(9)){
            winer = 2
        }
        //Cruzamento 2
        if (player1.contains(3) && player1.contains(5) && player1.contains(7)){
            winer = 1
        }
        if (player2.contains(3) && player2.contains(5) && player2.contains(7)){
            winer = 2
        }



        //Winer
        if (winer!=-1){
            if (winer==1){
                Toast.makeText(this,"Player 1 Win !",Toast.LENGTH_SHORT).show()
            }else{
                Toast.makeText(this,"Player 2 Win !",Toast.LENGTH_SHORT).show()
            }
        }

    }

}
